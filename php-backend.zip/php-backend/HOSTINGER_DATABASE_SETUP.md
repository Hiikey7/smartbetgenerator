# Hostinger Database Setup for PHP Backend

This guide explains how to set up the database for the PHP backend on Hostinger.

## Database Schema

The database schema is the same as the Node.js version and can be found in `backend/database/schema.sql`:

```sql
CREATE DATABASE IF NOT EXISTS smartbets;

USE smartbets;

CREATE TABLE IF NOT EXISTS betting_slips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matches JSON NOT NULL,
    paripesa_code VARCHAR(255) NOT NULL,
    afropari_code VARCHAR(255) NOT NULL,
    secret_bet_code VARCHAR(255) NOT NULL,
    total_odds DECIMAL(10, 2) NOT NULL,
    date DATE,
    name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Enable event scheduler
SET GLOBAL event_scheduler = ON;

-- Create a scheduled event to delete slips older than 30 days
CREATE EVENT IF NOT EXISTS delete_old_betting_slips
ON SCHEDULE EVERY 1 DAY
STARTS CURRENT_TIMESTAMP
DO
  DELETE FROM betting_slips
  WHERE created_at < DATE_SUB(NOW(), INTERVAL 30 DAY);
```

## Hostinger Database Setup Steps

1. **Create Database**:

   - Log in to your Hostinger hPanel
   - Go to "Databases" → "MySQL Databases"
   - Click "Create Database"
   - Note the database name, username, and password

2. **Import Schema**:

   - In hPanel, go to "Databases" → "phpMyAdmin"
   - Select your newly created database
   - Click the "Import" tab
   - Upload and execute the SQL file from `backend/database/schema.sql`

3. **Update Configuration**:
   - Edit `php-backend/config/database.php` with your Hostinger database credentials
   - The file automatically detects Hostinger hosting and uses the appropriate configuration

## Hostinger-Specific Considerations

1. **Event Scheduler**:

   - Some Hostinger plans may not allow setting GLOBAL variables
   - If you get an error with `SET GLOBAL event_scheduler = ON;`, you can skip this line
   - The cleanup event is not critical for the application to function

2. **JSON Column Support**:

   - The `matches` column uses JSON data type
   - This requires MySQL 5.7 or higher
   - Most Hostinger plans support this, but you can verify in phpMyAdmin

3. **Character Set**:
   - The schema uses `utf8mb4` character set
   - This is supported by Hostinger and allows full Unicode support

## Testing Database Connection

After setting up the database, you can test the connection by:

1. Uploading the `php-backend/test.php` file to your Hostinger account
2. Visiting the file in your browser
3. You should see connection success messages

If you encounter any database connection errors, verify:

- Database credentials in `config/database.php`
- Database exists and is accessible
- User has proper permissions to the database
