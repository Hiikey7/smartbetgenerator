<?php
// Redirect to the main application
header("Location: ../frontend/index.html");
exit();
?>