# PHP Backend for SmartBet Generator

This is the PHP/MySQL implementation of the SmartBet Generator backend API.

## File Structure

```
php-backend/
├── config/
│   └── database.php          # Database configuration
├── controllers/
│   └── BettingSlipController.php # API controller
├── models/
│   └── BettingSlip.php       # Betting slip model
├── .htaccess                  # URL rewriting rules
├── api.php                    # Main API entry point
└── test.php                   # Test script
```

## API Endpoints

All endpoints are accessed through `api.php` with a `path` parameter:

- `GET /api.php?path=betting-slips` - Get all betting slips
- `POST /api.php?path=betting-slips` - Save a new betting slip
- `GET /api.php?path=betting-slips/{id}` - Get a specific betting slip by ID
- `PUT /api.php?path=betting-slips/{id}` - Update a betting slip
- `DELETE /api.php?path=betting-slips/{id}` - Delete a betting slip
- `GET /api.php?path=betting-slips/analytics` - Get analytics data
- `GET /api.php?path=health` - Health check endpoint

## Database Schema

The database schema is the same as the original Node.js version:

```sql
CREATE DATABASE IF NOT EXISTS smartbets;

USE smartbets;

CREATE TABLE IF NOT EXISTS betting_slips (
    id INT AUTO_INCREMENT PRIMARY KEY,
    matches JSON NOT NULL,
    paripesa_code VARCHAR(255) NOT NULL,
    afropari_code VARCHAR(255) NOT NULL,
    secret_bet_code VARCHAR(255) NOT NULL,
    total_odds DECIMAL(10, 2) NOT NULL,
    date DATE,
    name VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

## Installation

1. Place all files in your web server directory
2. Update the database configuration in `config/database.php`
3. Ensure your web server has PHP and MySQL support
4. Make sure URL rewriting is enabled (Apache with mod_rewrite)

## Testing

Run `test.php` to verify the backend is working correctly.
